#' CrispyWaffle
#'
#' Exercise package
#'
#' @name CrispyWaffle
#' @docType package
NULL